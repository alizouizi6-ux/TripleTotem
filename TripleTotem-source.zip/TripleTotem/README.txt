TripleTotem 1.0.0
Target: Paper 26.3, Java 25
Owner: _Vayro

BEHAVIOR
- Direct melee hits from the player named _Vayro are tracked.
- If that hit causes the target's vanilla totem to activate within 3 seconds,
  the plugin checks the target's totem count at the resurrection event.
- If the target had at least 3 totems (including the first totem that is
  triggering), Minecraft consumes the first one normally. The plugin then
  consumes two more real totems, 2 ticks apart, and plays the totem animation,
  sound, and standard totem potion effects for each extra activation.
- If fewer than 3 totems were present, no extra totems are consumed.
- Only direct player melee damage is tracked; arrows/projectiles are not.

IMPORTANT LIMITATION
Minecraft only performs one genuine resurrection for the lethal hit. The second
and third activations are a visual/effect simulation and consume two real items;
they are not two additional independent saves from death.

BUILD
Requires JDK 25 and Gradle 8.14+ (or a compatible newer Gradle).
Run: gradle build
Output: build/libs/TripleTotem-1.0.0.jar

INSTALL
Put the JAR in the server's plugins folder and restart Paper 26.3.
