package com.vayro.tripletotem;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityResurrectEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class TripleTotemPlugin extends JavaPlugin implements Listener {
    private static final String OWNER_NAME = "_Vayro";
    private static final long HIT_WINDOW_MILLIS = 3_000L;

    private final Map<UUID, RecentHit> recentHits = new ConcurrentHashMap<>();

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("TripleTotem enabled. Owner: " + OWNER_NAME);
    }

    @Override
    public void onDisable() {
        recentHits.clear();
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerHit(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player target)) return;
        // A newer player hit replaces the previous attacker, so another player
        // cannot accidentally inherit _Vayro's recent-hit attribution.
        recentHits.remove(target.getUniqueId());
        if (!(event.getDamager() instanceof Player attacker)) return; // Direct melee hits only.
        if (!attacker.getName().equalsIgnoreCase(OWNER_NAME)) return;

        recentHits.put(target.getUniqueId(), new RecentHit(attacker.getUniqueId(), System.currentTimeMillis()));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTotemActivate(EntityResurrectEvent event) {
        if (!(event.getEntity() instanceof Player target)) return;

        RecentHit hit = recentHits.get(target.getUniqueId());
        if (hit == null) return;
        if (System.currentTimeMillis() - hit.timeMillis() > HIT_WINDOW_MILLIS) return;

        // Count the first totem as well: this event runs as the original resurrection is processed.
        if (countTotems(target.getInventory()) < 3) return;

        // The vanilla totem is consumed by Minecraft. Consume and visually simulate two more,
        // one after another, only if both additional real totems are still available.
        new BukkitRunnable() {
            private int remainingExtraActivations = 2;

            @Override
            public void run() {
                if (!target.isOnline() || remainingExtraActivations <= 0) {
                    cancel();
                    return;
                }
                if (!consumeOneTotem(target.getInventory())) {
                    cancel();
                    return;
                }

                playExtraTotemEffect(target);
                remainingExtraActivations--;
                if (remainingExtraActivations <= 0) cancel();
            }
        }.runTaskTimer(this, 1L, 2L);
    }

    private int countTotems(PlayerInventory inventory) {
        int count = 0;
        for (ItemStack item : inventory.getStorageContents()) {
            if (item != null && item.getType() == Material.TOTEM_OF_UNDYING) {
                count += item.getAmount();
            }
        }
        ItemStack offhand = inventory.getItemInOffHand();
        if (offhand.getType() == Material.TOTEM_OF_UNDYING) count += offhand.getAmount();
        return count;
    }

    private boolean consumeOneTotem(PlayerInventory inventory) {
        ItemStack offhand = inventory.getItemInOffHand();
        if (offhand.getType() == Material.TOTEM_OF_UNDYING) {
            decrement(offhand);
            if (offhand.getAmount() <= 0) inventory.setItemInOffHand(null);
            return true;
        }

        ItemStack[] contents = inventory.getStorageContents();
        for (int slot = 0; slot < contents.length; slot++) {
            ItemStack item = contents[slot];
            if (item == null || item.getType() != Material.TOTEM_OF_UNDYING) continue;
            decrement(item);
            if (item.getAmount() <= 0) contents[slot] = null;
            inventory.setStorageContents(contents);
            return true;
        }
        return false;
    }

    private void decrement(ItemStack item) {
        item.setAmount(item.getAmount() - 1);
    }

    private void playExtraTotemEffect(Player player) {
        player.playEffect(org.bukkit.EntityEffect.TOTEM_RESURRECT);
        player.getWorld().playSound(player.getLocation(), Sound.ITEM_TOTEM_USE, 1.0f, 1.0f);
        player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 900, 1, false, true, true));
        player.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 100, 1, false, true, true));
        player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 800, 0, false, true, true));
    }

    private record RecentHit(UUID attackerId, long timeMillis) { }
}
